"""
train.py
--------
End-to-end training pipeline:

  1. Load metadata & build a speaker-disjoint train/val/test split.
  2. Build (or load cached) hybrid feature vectors for every clip.
  3. Train the speaker-agnostic "general" embedding model
     (FeatureFusion -> ProjectionHead -> classifier head), jointly
     optimizing cross-entropy + a triplet/contrastive embedding loss.
  4. Evaluate the general model on the test split.
  5. Pre-compute embeddings for train/val and train the personalization
     head (CrossAttentionModule + PersonalizedRepresentation +
     DeepfakeClassifier) using leave-one-out same-speaker memory batches.

Run:
    python train.py
"""

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from src.dataset import build_all_feature_caches, build_dataloaders, load_metadata, make_splits
from src.evaluation import evaluate_probs, plot_confusion_matrices, plot_roc_curve
from src.features import HybridFeatureExtractor
from src.memory import CrossAttentionModule
from src.model import DeepfakeClassifier, PersonalizedRepresentation, build_general_model
from src.utils import (
    DEVICE, build_group_slices, build_loo_memory_batch, config,
    create_negative_pairs, create_positive_pairs, print_device_info, set_seed,
)


def train_general_model(general_model, train_loader, val_loader, group_slices):
    for p in general_model.parameters():
        p.requires_grad = True

    y_train_all = torch.cat([yb for _, yb, _ in train_loader]).numpy()
    cls_counts = np.bincount(y_train_all, minlength=2).astype(np.float32)
    cls_weights = torch.tensor(
        cls_counts.sum() / (2.0 * cls_counts), dtype=torch.float32).to(DEVICE)
    print(f"Class counts (train) bona-fide={int(cls_counts[0])} spoof={int(cls_counts[1])} "
          f"-> CE weights={cls_weights.cpu().numpy()}")

    ce_loss_fn = nn.CrossEntropyLoss(weight=cls_weights)
    triplet_loss_fn = nn.TripletMarginLoss(margin=config.TRIPLET_MARGIN, p=2)
    optimizer = optim.Adam(general_model.parameters(), lr=config.LEARNING_RATE, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config.EPOCHS, eta_min=1e-5)

    def contrastive_loss(embeddings, labels, speakers):
        pos_idx = create_positive_pairs(labels, speakers)
        neg_idx = create_negative_pairs(labels, speakers)
        return triplet_loss_fn(embeddings, embeddings[pos_idx], embeddings[neg_idx])

    def run_epoch(loader, train_mode):
        general_model.train(train_mode)
        total_loss, correct, total = 0.0, 0, 0
        for xb, yb, spk in loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            with torch.set_grad_enabled(train_mode):
                embedding, logits, _ = general_model(xb)
                ce = ce_loss_fn(logits, yb)
                triplet = contrastive_loss(embedding, yb, spk)
                loss = ce + config.LAMBDA_TRIPLET * triplet
                if train_mode:
                    optimizer.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(general_model.parameters(), max_norm=1.0)
                    optimizer.step()
            total_loss += loss.item() * len(yb)
            preds = logits.argmax(dim=1)
            correct += (preds == yb).sum().item()
            total += len(yb)
        return total_loss / total, correct / total

    history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    best_val_loss = float("inf")
    patience, patience_counter = 5, 0

    for epoch in range(1, config.EPOCHS + 1):
        train_loss, train_acc = run_epoch(train_loader, train_mode=True)
        val_loss, val_acc = run_epoch(val_loader, train_mode=False)
        scheduler.step()

        history["train_loss"].append(train_loss); history["train_acc"].append(train_acc)
        history["val_loss"].append(val_loss); history["val_acc"].append(val_acc)
        print(f"Epoch {epoch:02d}/{config.EPOCHS}  train_loss={train_loss:.4f} train_acc={train_acc:.4f}  "
              f"val_loss={val_loss:.4f} val_acc={val_acc:.4f}")

        if val_loss < best_val_loss:
            best_val_loss, patience_counter = val_loss, 0
            torch.save(general_model.state_dict(), config.EMBED_MODEL_PATH)
            print(f"  \u2713 saved best general model (val_loss={val_loss:.4f})")
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"  Early stopping at epoch {epoch}")
                break

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    ep = range(1, len(history["train_loss"]) + 1)
    ax1.plot(ep, history["train_loss"], label="Train"); ax1.plot(ep, history["val_loss"], label="Val")
    ax1.set_title("Loss (CE + \u03bb\u00b7Triplet)"); ax1.legend()
    ax2.plot(ep, history["train_acc"], label="Train"); ax2.plot(ep, history["val_acc"], label="Val")
    ax2.set_title("Accuracy"); ax2.legend()
    plt.tight_layout(); plt.savefig(config.HISTORY_PLOT_PATH, dpi=150); plt.show()

    return history, ce_loss_fn


def evaluate_general_model(general_model, test_loader):
    general_model.load_state_dict(torch.load(config.EMBED_MODEL_PATH, map_location=DEVICE))
    general_model.eval()

    all_labels, all_probs, all_embeddings = [], [], []
    with torch.no_grad():
        for xb, yb, spk in test_loader:
            xb = xb.to(DEVICE)
            embedding, logits, _ = general_model(xb)
            probs = torch.softmax(logits, dim=1)[:, 1].cpu().numpy()
            all_probs.extend(probs.tolist())
            all_labels.extend(yb.numpy().tolist())
            all_embeddings.append(embedding.cpu().numpy())

    all_labels = np.array(all_labels)
    all_probs = np.array(all_probs)
    all_embeddings = np.concatenate(all_embeddings, axis=0)

    result = evaluate_probs(all_labels, all_probs, threshold=0.5)
    print(result["report"])
    print(f"\nAUC = {result['auc']:.4f}   EER = {result['eer'] * 100:.2f}%")

    eer_t, _ = None, None
    from src.evaluation import eer_threshold
    eer_t, _ = eer_threshold(all_labels, all_probs)
    result_eer = evaluate_probs(all_labels, all_probs, threshold=eer_t)
    print(f"\n--- Classification report @ EER threshold ({eer_t:.4f}) instead of default 0.5 ---")
    print(result_eer["report"])

    plot_confusion_matrices(all_labels, [result["preds"]], ["General Detector"])
    plot_roc_curve(all_labels, all_probs, title="ROC Curve (General Model)")

    return all_labels, all_probs, all_embeddings


def embed_all(general_model, X):
    general_model.eval()
    embs = []
    with torch.no_grad():
        for i in range(0, len(X), 256):
            xb = torch.from_numpy(X[i:i + 256]).float().to(DEVICE)
            emb, _, _ = general_model(xb)
            embs.append(emb.cpu().numpy())
    return np.concatenate(embs, axis=0)


def train_personalization_head(general_model, X_train, y_train, spk_train,
                                X_val, y_val, spk_val, ce_loss_fn):
    for p in general_model.parameters():
        p.requires_grad_(False)
    general_model.eval()

    train_embeddings = embed_all(general_model, X_train)
    val_embeddings = embed_all(general_model, X_val)
    print("Pre-computed embeddings:", train_embeddings.shape, val_embeddings.shape)

    cross_attention = CrossAttentionModule().to(DEVICE)
    personalizer = PersonalizedRepresentation().to(DEVICE)
    personalized_classifier = DeepfakeClassifier().to(DEVICE)

    personalization_params = (list(cross_attention.parameters())
                               + list(personalizer.parameters())
                               + list(personalized_classifier.parameters()))
    p_optimizer = optim.Adam(personalization_params, lr=config.LEARNING_RATE)
    p_scheduler = optim.lr_scheduler.CosineAnnealingLR(p_optimizer, T_max=config.P_EPOCHS, eta_min=1e-5)

    def run_personalization_epoch(embeddings, y, speakers, train_mode, memory_drop_prob=0.0):
        modules = [cross_attention, personalizer, personalized_classifier]
        for m in modules:
            m.train(train_mode)
        idx_all = np.arange(len(y))
        if train_mode:
            np.random.shuffle(idx_all)
        total_loss, correct, total = 0.0, 0, 0
        for start in range(0, len(idx_all), config.BATCH_SIZE):
            batch_idx = idx_all[start:start + config.BATCH_SIZE]
            cur_emb = torch.from_numpy(embeddings[batch_idx]).float().to(DEVICE)
            labels_b = torch.from_numpy(y[batch_idx]).long().to(DEVICE)
            mem, mask = build_loo_memory_batch(
                batch_idx, embeddings, y, speakers, config.EMBED_DIM, config.MEMORY_TOPK,
                drop_prob=memory_drop_prob if train_mode else 0.0,
            )
            mem, mask = mem.to(DEVICE), mask.to(DEVICE)

            with torch.set_grad_enabled(train_mode):
                context, _ = cross_attention(cur_emb, mem, retrieved_mask=mask)
                personalized_emb = personalizer(cur_emb, context)
                logits = personalized_classifier.predict(personalized_emb)
                loss = ce_loss_fn(logits, labels_b)
                if train_mode:
                    p_optimizer.zero_grad()
                    loss.backward()
                    p_optimizer.step()

            total_loss += loss.item() * len(labels_b)
            preds = logits.argmax(dim=1)
            correct += (preds == labels_b).sum().item()
            total += len(labels_b)
        return total_loss / total, correct / total

    p_history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    best_p_val_loss = float("inf")
    p_patience_counter = 0

    for epoch in range(1, config.P_EPOCHS + 1):
        tr_loss, tr_acc = run_personalization_epoch(
            train_embeddings, y_train, spk_train, True, memory_drop_prob=config.MEMORY_DROPOUT_PROB)
        va_loss, va_acc = run_personalization_epoch(val_embeddings, y_val, spk_val, False)
        p_scheduler.step()
        p_history["train_loss"].append(tr_loss); p_history["train_acc"].append(tr_acc)
        p_history["val_loss"].append(va_loss); p_history["val_acc"].append(va_acc)
        print(f"[Personalization] Epoch {epoch:02d}/{config.P_EPOCHS}  "
              f"train_loss={tr_loss:.4f} train_acc={tr_acc:.4f}  val_loss={va_loss:.4f} val_acc={va_acc:.4f}")

        if va_loss < best_p_val_loss:
            best_p_val_loss, p_patience_counter = va_loss, 0
            torch.save({
                "cross_attention": cross_attention.state_dict(),
                "personalizer": personalizer.state_dict(),
                "personalized_classifier": personalized_classifier.state_dict(),
            }, config.HEAD_MODEL_PATH)
            print(f"  \u2713 saved best personalization head (val_loss={va_loss:.4f})")
        else:
            p_patience_counter += 1
            if p_patience_counter >= config.P_PATIENCE:
                print(f"  Early stopping personalization at epoch {epoch}")
                break

    print(f"Best personalization head saved -> {config.HEAD_MODEL_PATH} (val_loss={best_p_val_loss:.4f})")
    return p_history


def main():
    set_seed(config.RANDOM_SEED)
    print_device_info()

    print("Loading metadata ...")
    df = load_metadata()
    train_df, val_df, test_df = make_splits(df)
    print(f"\nTrain: {len(train_df):,}  Val: {len(val_df):,}  Test: {len(test_df):,}")

    feature_extractor = HybridFeatureExtractor()
    print("HybridFeatureExtractor ready. XLS-R enabled:", feature_extractor._xlsr_model is not None)

    train_data, val_data, test_data = build_all_feature_caches(train_df, val_df, test_df, feature_extractor)
    X_train, y_train, spk_train = train_data
    X_val, y_val, spk_val = val_data
    X_test, y_test, spk_test = test_data

    train_loader, val_loader, test_loader = build_dataloaders(train_data, val_data, test_data)

    group_slices, total_dim = build_group_slices(config.FEATURE_GROUP_DIMS, config.DIM_XLSR)
    assert total_dim == X_train.shape[1], f"{total_dim} != {X_train.shape[1]}"
    print("Feature group slices:", group_slices)

    general_model = build_general_model(group_slices)
    print(general_model)

    _, ce_loss_fn = train_general_model(general_model, train_loader, val_loader, group_slices)
    evaluate_general_model(general_model, test_loader)

    train_personalization_head(
        general_model, X_train, y_train, spk_train, X_val, y_val, spk_val, ce_loss_fn)

    print("\nTraining complete. Run inference.py for the personalized deployment simulation.")


if __name__ == "__main__":
    main()
