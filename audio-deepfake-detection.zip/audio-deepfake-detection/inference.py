"""
inference.py
------------
Deployment simulation: replays the test split through the trained general
model + personalization head, using the Adaptive Memory Retriever /
Memory Quality Controller / Memory Update Controller pipeline to grow a
persistent per-speaker memory bank sample-by-sample (as it would in a real
deployment), then reports general vs. personalized metrics and writes
outputs/submission.csv.

Run (after train.py has produced models/rat_embedding_model.pt and
models/rat_personalized_head.pt):
    python inference.py
"""

import os

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, f1_score

from src.dataset import load_metadata, make_splits
from src.evaluation import (
    best_f1_threshold, compare_general_vs_personalized, eer_threshold,
    evaluate_probs, memory_bank_stats, plot_confusion_matrices,
)
from src.memory import CrossAttentionModule, build_memory_system
from src.model import DeepfakeClassifier, PersonalizedRepresentation, build_general_model
from src.utils import (
    DEVICE, build_group_slices, config, print_device_info, print_saved_artifacts, set_seed,
)


def load_test_features():
    """Loads the cached test-split feature matrix (must already exist from
    train.py's build_all_feature_caches call) plus the test dataframe."""
    df = load_metadata()
    train_df, val_df, test_df = make_splits(df)

    cache_path = os.path.join(config.OUTPUT_DIR, f"feat_test_{config.FEATURE_CACHE_VERSION}.npz")
    if not os.path.exists(cache_path):
        raise FileNotFoundError(
            f"{cache_path} not found — run train.py first to build the feature caches."
        )
    data = np.load(cache_path, allow_pickle=True)
    return data["X"], data["y"], data["speakers"], test_df, train_df, val_df


def embed_all(general_model, X):
    general_model.eval()
    embs = []
    with torch.no_grad():
        for i in range(0, len(X), 256):
            xb = torch.from_numpy(X[i:i + 256]).float().to(DEVICE)
            emb, _, _ = general_model(xb)
            embs.append(emb.cpu().numpy())
    return np.concatenate(embs, axis=0)


def run_deployment_replay(general_model, cross_attention, personalizer, personalized_classifier,
                           memory_system, X_test, y_test, spk_test, group_slices):
    memory_bank = memory_system["memory_bank"]
    adaptive_retriever = memory_system["adaptive_retriever"]
    quality_controller = memory_system["quality_controller"]
    confidence_gate = memory_system["confidence_gate"]
    update_controller = memory_system["update_controller"]

    general_model.eval(); cross_attention.eval(); personalizer.eval(); personalized_classifier.eval()

    test_embeddings = embed_all(general_model, X_test)
    physics_start, physics_end = group_slices["physics"]

    order = np.argsort(spk_test, kind="stable")

    general_preds, personalized_preds, true_labels = [], [], []
    general_probs_spoof, personalized_probs_spoof = [], []
    memory_writes, prototype_compressions = 0, 0
    topk_used, complexity_used = [], []

    with torch.no_grad():
        for i in order:
            speaker_id = str(spk_test[i])
            true_label = int(y_test[i])
            cur_emb_np = test_embeddings[i]
            cur_emb = torch.from_numpy(cur_emb_np).float().unsqueeze(0).to(DEVICE)
            physics_vec = X_test[i, physics_start:physics_end].astype(np.float32)

            xb = torch.from_numpy(X_test[i:i + 1]).float().to(DEVICE)
            _, gen_logits, _ = general_model(xb)
            gen_probs = torch.softmax(gen_logits, dim=1).cpu().numpy()[0]
            gen_pred = int(gen_probs.argmax())
            general_preds.append(gen_pred)
            general_probs_spoof.append(float(gen_probs[1]))

            is_first = not memory_bank.hasSpeaker(speaker_id)
            if is_first:
                refs = np.zeros((0, config.EMBED_DIM), dtype=np.float32)
                sims = np.array([]); used_k, complexity = 0, 0.0
            else:
                refs, sims, _age_w, used_k, complexity = adaptive_retriever.retrieveNearest(speaker_id, cur_emb_np)
            topk_used.append(used_k); complexity_used.append(complexity)

            k = refs.shape[0]
            if k > 0:
                mem = torch.from_numpy(refs).float().unsqueeze(0).to(DEVICE)
                mask = torch.ones(1, k, dtype=torch.bool).to(DEVICE)
                context, _ = cross_attention(cur_emb, mem, retrieved_mask=mask)
            else:
                context = torch.zeros(1, config.EMBED_DIM).to(DEVICE)
            personalized_emb = personalizer(cur_emb, context)
            pred_class_t, probs_t = personalized_classifier(personalized_emb)
            pred_class = int(pred_class_t.item())
            personalized_preds.append(pred_class)
            personalized_probs_spoof.append(float(probs_t.detach().cpu().numpy()[0][1]))
            true_labels.append(true_label)

            confidence = quality_controller.computeConfidence(gen_probs, gen_pred)
            similarity = quality_controller.computeSimilarity(sims)
            physics_score = quality_controller.computePhysicsScore(memory_bank, speaker_id, physics_vec)

            written, compressed = update_controller.processUpdate(
                quality_controller, confidence_gate, speaker_id, cur_emb_np, physics_vec,
                gen_pred, confidence, similarity, physics_score, is_first,
            )
            if written:
                memory_writes += 1
            if compressed:
                prototype_compressions += 1

    memory_bank.rebuildIndex()

    results = {
        "order": order,
        "general_preds": np.array(general_preds),
        "personalized_preds": np.array(personalized_preds),
        "true_labels": np.array(true_labels),
        "general_probs_spoof": np.array(general_probs_spoof),
        "personalized_probs_spoof": np.array(personalized_probs_spoof),
        "memory_writes": memory_writes,
        "prototype_compressions": prototype_compressions,
        "topk_used": topk_used,
        "complexity_used": complexity_used,
    }

    print(f"Replayed {len(true_labels)} test samples across {len(set(spk_test))} speakers.")
    print(f"Memory writes (genuine, gated)   : {memory_writes}")
    print(f"Prototype compressions triggered : {prototype_compressions}")
    print(f"Adaptive Top-K used  -> mean={np.mean(topk_used):.2f}  min={int(np.min(topk_used))}  "
          f"max={int(np.max(topk_used))}")
    print(f"Speaker complexity   -> mean={np.mean(complexity_used):.3f}")
    print(f"\nGeneral model accuracy      : {accuracy_score(results['true_labels'], results['general_preds']):.4f}")
    print(f"Personalized model accuracy : {accuracy_score(results['true_labels'], results['personalized_preds']):.4f}")
    print(f"General model F1            : {f1_score(results['true_labels'], results['general_preds']):.4f}")
    print(f"Personalized model F1       : {f1_score(results['true_labels'], results['personalized_preds']):.4f}")

    return results


def write_submission(test_df, results):
    order = results["order"]
    test_df_ordered = test_df.iloc[order].reset_index(drop=True)

    true_labels = results["true_labels"]
    assert len(test_df_ordered) == len(true_labels), (
        f"Row count mismatch: test_df_ordered has {len(test_df_ordered)} rows but "
        f"true_labels has {len(true_labels)}. Re-run the deployment replay before this step."
    )

    submission_df = pd.DataFrame({
        "file": test_df_ordered["file"].values,
        "speaker": test_df_ordered["speaker"].values,
        "true_label": test_df_ordered["label"].values,
        "general_pred_label": [config.INVERSE_LABEL_MAP[p] for p in results["general_preds"]],
        "general_correct": (results["general_preds"] == true_labels),
        "personalized_pred_label": [config.INVERSE_LABEL_MAP[p] for p in results["personalized_preds"]],
        "personalized_correct": (results["personalized_preds"] == true_labels),
    })

    submission_df.to_csv(config.SUBMISSION_PATH, index=False)
    print(f"submission.csv saved -> {config.SUBMISSION_PATH}")
    print(f"Rows: {len(submission_df):,}")
    return submission_df


def main():
    set_seed(config.RANDOM_SEED)
    print_device_info()

    X_test, y_test, spk_test, test_df, train_df, val_df = load_test_features()

    # Leakage guard: test speakers must be disjoint from train/val speakers.
    train_val_speakers = set(train_df["speaker"]) | set(val_df["speaker"])
    test_speakers = set(test_df["speaker"])
    leak = train_val_speakers & test_speakers
    assert not leak, f"Speaker leakage detected: {leak}"
    print(f"Leakage guard OK: {len(test_speakers)} test speakers, 0 overlap with train/val.")

    group_slices, total_dim = build_group_slices(config.FEATURE_GROUP_DIMS, config.DIM_XLSR)

    # --- Load trained general model ---------------------------------------
    general_model = build_general_model(group_slices)
    general_model.load_state_dict(torch.load(config.EMBED_MODEL_PATH, map_location=DEVICE))
    general_model.eval()

    # --- Load trained personalization head ---------------------------------
    cross_attention = CrossAttentionModule().to(DEVICE)
    personalizer = PersonalizedRepresentation().to(DEVICE)
    personalized_classifier = DeepfakeClassifier().to(DEVICE)
    ckpt = torch.load(config.HEAD_MODEL_PATH, map_location=DEVICE)
    cross_attention.load_state_dict(ckpt["cross_attention"])
    personalizer.load_state_dict(ckpt["personalizer"])
    personalized_classifier.load_state_dict(ckpt["personalized_classifier"])
    print(f"Loaded best personalization head from {config.HEAD_MODEL_PATH}")

    # --- Fresh memory bank for this deployment simulation -------------------
    memory_system = build_memory_system()

    # --- Replay the test split, growing memory sample-by-sample -------------
    results = run_deployment_replay(
        general_model, cross_attention, personalizer, personalized_classifier,
        memory_system, X_test, y_test, spk_test, group_slices,
    )

    # --- Reporting ----------------------------------------------------------
    plot_confusion_matrices(
        results["true_labels"], [results["general_preds"], results["personalized_preds"]],
        ["General Detector", "Personalized Detector"],
    )
    comparison_df = compare_general_vs_personalized(
        results["true_labels"], results["general_preds"], results["personalized_preds"])
    print(comparison_df)

    p_eer_t, p_eer = eer_threshold(results["true_labels"], results["personalized_probs_spoof"])
    p_f1_t = best_f1_threshold(results["true_labels"], results["personalized_probs_spoof"])
    print(f"\nPersonalized model: EER={p_eer * 100:.2f}% @ threshold={p_eer_t:.4f}  |  "
          f"best-F1 threshold={p_f1_t:.4f}")

    for label, thresh in [("default 0.5", 0.5), (f"EER threshold ({p_eer_t:.4f})", p_eer_t),
                           (f"best-F1 threshold ({p_f1_t:.4f})", p_f1_t)]:
        res = evaluate_probs(results["true_labels"], results["personalized_probs_spoof"], threshold=thresh)
        print(f"\n--- Personalized model @ {label} ---")
        print(res["report"])

    # --- Submission + memory bank stats -------------------------------------
    write_submission(test_df, results)
    memory_bank_stats(memory_system["memory_bank"])
    print_saved_artifacts()


if __name__ == "__main__":
    main()
