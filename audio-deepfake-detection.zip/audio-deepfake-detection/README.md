# Audio Deepfake Detection (In-the-Wild)

A hybrid audio-deepfake / voice-spoofing detector combining classic
spoof-countermeasure features (MFCC, LFCC, CQCC), spectral/prosodic/physics
features (jitter, shimmer, HNR, formant stability), and self-supervised
XLS-R embeddings, fused through a learned attention gate into a contrastive
speaker-embedding space — plus a **novel per-speaker memory-bank
personalization system** that adapts the detector to each speaker's voice
over time as it sees more genuine samples of them.

Originally developed against the ["In the Wild" audio deepfake dataset](
https://www.kaggle.com/datasets/abdallamohamed312/in-the-wild-audio-deepfake).

## Architecture

```
Audio file
   │
   ▼
AudioProcessor (load / VAD-trim / normalize / fixed-length segment)
   │
   ▼
HybridFeatureExtractor
   ├─ MFCC / CQCC / LFCC          (spoof artifacts)
   ├─ Spectral (centroid, rolloff, contrast, chroma, RMS, ZCR)
   ├─ Prosody (pitch, speaking rate, pause ratio)
   ├─ Physics (jitter, shimmer, HNR, formant stability)
   └─ XLS-R embedding              (self-supervised, optional)
   │
   ▼
FeatureFusion (per-group LayerNorm + learned attention gate)
   │
   ▼
ProjectionHead → 256-D L2-normalized embedding ──► classifier ──► bona-fide / spoof
   │                                    (General Detector)
   │
   ▼ (at inference / deployment time)
AdaptiveMemoryRetriever ──► per-speaker MemoryBank (SQLite + FAISS)
   │  (dynamic Top-K driven by an acoustic-complexity estimate)
   ▼
CrossAttentionModule → speaker context
   │
   ▼
PersonalizedRepresentation → personalized embedding ──► DeepfakeClassifier
                                       (Personalized Detector)
```

New embeddings only enter a speaker's memory bank once they pass a strict
**ConfidenceGate** (prediction confidence + physics-consistency + embedding
similarity checks). A **MemoryAgingManager** decays the influence of old
entries over time, and a **PrototypeMemoryManager** compresses a speaker's
raw entries into a bounded set of representative centroids once their
count crosses a trigger threshold — keeping retrieval fast and the memory
footprint bounded even for long-lived deployments.

## Project structure

```
audio-deepfake-detection/
│
├── README.md
├── requirements.txt
├── train.py                  # Train the general model + personalization head
├── inference.py               # Deployment replay simulation + submission.csv
│
├── data/                      # Place the dataset here (or point AUDIO_DIR / META_CSV elsewhere)
├── models/                    # Saved model checkpoints (.pt)
├── outputs/                   # Feature caches, memory bank DB, plots, submission.csv
│
└── src/
    ├── preprocessing.py        # AudioProcessor, AudioAugmentor
    ├── features.py              # HybridFeatureExtractor (MFCC/LFCC/CQCC/spectral/prosody/physics/XLS-R)
    ├── dataset.py                # Metadata loading, speaker-disjoint splits, feature cache, Dataset/DataLoader
    ├── model.py                   # FeatureFusion, ProjectionHead, GeneralEmbeddingModel, DeepfakeClassifier
    ├── memory.py                   # MemoryBank, CrossAttentionModule, retrieval, aging, prototype compression, gating
    ├── evaluation.py                # Accuracy, EER, ROC-AUC, F1, confusion matrices, memory bank stats
    └── utils.py                     # Config, device/seed setup, contrastive-pairing & LOO-memory-batch helpers
```

## Setup

```bash
pip install -r requirements.txt
```

### Getting the dataset

The dataset (~5GB) is **not** included in this repo — `data/` is git-ignored
on purpose (see `.gitignore`). Get it one of two ways:

**Option A — automatic (recommended):**
```bash
pip install kagglehub
python download_data.py
```
This downloads the ["In the Wild" audio deepfake dataset](
https://www.kaggle.com/datasets/abdallamohamed312/in-the-wild-audio-deepfake)
straight into `data/` (prompts for a Kaggle login/API token the first time).

**Option B — manual:** download the dataset from Kaggle yourself and place
it so you end up with:
```
data/release_in_the_wild/real/*.wav
data/release_in_the_wild/fake/*.wav
data/meta.csv
```

Then point the pipeline at it via environment variables (only needed if
your folder names differ from the defaults above):

```bash
export AUDIO_DIR=/path/to/release_in_the_wild   # contains real/ and fake/ subfolders
export META_CSV=/path/to/meta.csv               # columns: file, label, [speaker]
```

### Pushing this repo to GitHub

`data/`, `models/*.pt`, and `outputs/*` are all git-ignored (only `.gitkeep`
placeholders are tracked) — so `git add . && git push` will only ever send
your ~50KB of source code, never the multi-GB dataset or model checkpoints.
Anyone who clones the repo just runs `python download_data.py` (or Option B
above) and `python train.py` to regenerate everything locally.

## Usage

**1. Train** the general embedding model and the speaker-personalization head:

```bash
python train.py
```

This will:
- Build a speaker-disjoint 70/15/15 train/val/test split.
- Extract and cache hybrid features per split under `outputs/`.
- Train the general (speaker-agnostic) detector with a combined
  cross-entropy + triplet loss, saving the best checkpoint to
  `models/rat_embedding_model.pt`.
- Evaluate the general model (classification report, AUC, EER, ROC).
- Freeze the general model and train the personalization head
  (cross-attention over leave-one-out same-speaker memory batches),
  saving the best checkpoint to `models/rat_personalized_head.pt`.

**2. Run inference / the deployment simulation:**

```bash
python inference.py
```

This replays the test split speaker-by-speaker through a fresh memory
bank, gating which genuine samples get written into speaker memory,
compressing memory via prototypes once it grows large, and reports
general-vs-personalized accuracy/F1/EER alongside `outputs/submission.csv`
and per-speaker memory bank statistics.

## Notes

- Any optional dependency (`spafe`, `praat-parselmouth`, `transformers`,
  `faiss-cpu`) that isn't installed is detected automatically at import
  time and the pipeline falls back to a librosa-based approximation (or
  disables the XLS-R branch / FAISS acceleration) rather than failing.
- Feature caches are versioned via `Config.FEATURE_CACHE_VERSION` — bump it
  if you change feature extraction and want to force a rebuild.
- Set `Config.RESET_MEMORY_DB = False` if you want the speaker memory bank
  to persist across separate `inference.py` runs instead of resetting
  every time.
